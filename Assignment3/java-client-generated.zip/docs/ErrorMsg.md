# ErrorMsg

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**msg** | **String** |  |  [optional]
