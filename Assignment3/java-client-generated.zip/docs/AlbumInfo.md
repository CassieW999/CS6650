# AlbumInfo

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**artist** | **String** | album performers |  [optional]
**title** | **String** | album title |  [optional]
**year** | **String** | year released |  [optional]
