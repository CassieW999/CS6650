# ImageMetaData

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**albumID** | **String** |  |  [optional]
**imageSize** | **String** |  |  [optional]
